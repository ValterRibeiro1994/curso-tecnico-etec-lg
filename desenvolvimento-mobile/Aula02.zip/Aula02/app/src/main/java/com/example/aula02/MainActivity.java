package com.example.aula02;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText inputNome, inputCargo, inputSalario;
    TextView outputResponse;
    Button btnSair, btnLimpar, btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // linkando os elementos no Java
        // Elementos de entrada
        inputNome = findViewById(R.id.inputNome);
        inputCargo = findViewById(R.id.inputCargo);
        inputSalario = findViewById(R.id.inputSalario);

        // Botões de evento
        btnCalcular = findViewById(R.id.btnCalcular);
        btnSair = findViewById(R.id.btnSair);
        btnLimpar = findViewById(R.id.btnLimpar);

        // Elementos de resposta
        outputResponse = findViewById(R.id.outputResponse);

        // Criando evento para calcular o aumento salarial
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // captura o valor digitado
                String salarioDigitado = inputSalario.getText().toString();
                double salarioUsuario; // armazenar o valor do salario convertido
                double salarioFinal;

                // verifica se o campo não está vazio
                if (salarioDigitado.isEmpty()){
                    outputResponse.setText("Por favor cabaço, como calcula aumento de sálario se ele não for digitado em !!!");
                } else { // se não

                    // troca virgula por ponto se necessario
                    salarioDigitado = salarioDigitado.replace(",", ".");

                    // verifica se o valor é numerico
                    try {
                        salarioUsuario = Double.parseDouble(salarioDigitado); // converte string para double

                        // calcula o aumento de 15%
                        salarioFinal = salarioUsuario * 1.15;

                        // captura o nome e o cargo digitado
                        String nomeUsuario = inputNome.getText().toString();
                        String cargoUsuario = inputCargo.getText().toString();

                        String resposta = "Nome: " + nomeUsuario + "\n" + "Cargo: " + cargoUsuario + "\n" + "Salario antigo: " + salarioUsuario + "\n" + "Novo sálario: " + salarioFinal;
                        outputResponse.setText(resposta);

                        Toast.makeText(MainActivity.this, "Parabens pelo aumento cabaço :)", Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        outputResponse.setText("Cabaço Informe números e não letras ");
                        Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG).show();
                    }
                }


            }});

        // criando o evento para limpar todos os campos
        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputSalario.setText("");
                inputCargo.setText("");
                inputNome.setText("");
                Toast.makeText(MainActivity.this, "Todos os campos foram limpos cabaço", Toast.LENGTH_LONG).show();
            }
        });

        // criando o evento para sair da aplicação
        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Obrigado volte sempre cabaço rsrs", Toast.LENGTH_LONG).show();
                finishAffinity();
            }
        });
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}