package com.example.aula05;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // elementos
    EditText inputPreco, inputPercentual;
    TextView outputResposta;
    Button btnAumento, btnDesconto;
    // variaveis auxiliares
    String valorInput, percentualInput;
    double valorInputNumero, percentualInputNumero, resultadoCalculo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // iniciando elementos
        inputPreco = findViewById(R.id.inputPreco);
        inputPercentual = findViewById(R.id.inputPercentual);
        outputResposta = findViewById(R.id.outputResultado);
        btnAumento = findViewById(R.id.btnAumento);
        btnDesconto = findViewById(R.id.btnDesconto);

        // iniciar evento desconto
        btnDesconto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validarEntradas()){
                    resultadoCalculo = calcularDesconto(valorInputNumero, percentualInputNumero);
                    enviarResultado("Valor anterior: " + valorInput + "\n" + "Valor com Desconto: " + resultadoCalculo);

                }
            }
        });

        // iniciar evento Aumento
        btnAumento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validarEntradas()){
                    resultadoCalculo = calcularAumento(valorInputNumero, percentualInputNumero);
                    enviarResultado("Valor anterior: " + valorInput + "\n" + "Valor com Aumento: " + resultadoCalculo);
                }
            }

        });

        // iniciar eventos com clique longo
        btnDesconto.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (!validarEntradas()){
                    // vai que o ser humano da o clique longo antes de qualquer coisa neh !
                    return false;
                }
                resultadoCalculo = calcularDesconto(valorInputNumero, percentualInputNumero);
                double diferenca = valorInputNumero - resultadoCalculo;
                enviarToast("Foi aplicado um desconto de " + diferenca);
                return false;
            }
        });

        btnAumento.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (!validarEntradas()){
                    // vai que o ser humano da o clique longo antes de qualquer coisa neh !
                    return false;
                }
                resultadoCalculo = calcularAumento(valorInputNumero, percentualInputNumero);
                double aumento = resultadoCalculo - valorInputNumero;
                enviarToast("Foi aplicado um aumento de " + aumento);
                return false;
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // método para calcular aumento
    private double calcularAumento(double valor, double percentual){
        return valor + (valor * (percentual / 100));
    }

    // metodo para calcular Desconto
    private double calcularDesconto(double valor, double percentual){
        return valor - (valor * (percentual / 100));
    }

    // método para verificar se a entrada esta vazia
    private boolean checarEntrada(String entrada){
        return entrada != null && !entrada.isEmpty();
    }

    private void enviarToast(String mensagem){
        Toast.makeText(MainActivity.this, mensagem, Toast.LENGTH_LONG).show();
    }

    private void enviarResultado(String mensagem){
        outputResposta.setText(mensagem);
    }

    private boolean validarEntradas(){

        // Validar campos vazios
        if (!checarEntrada(inputPreco.getText().toString())){
            enviarToast("Informe o valor a ser calculado !!!!");
            enviarResultado("Campo Valor está vazio, informe um valor para ser calculado");
            return false;
        }

        if (!checarEntrada(inputPercentual.getText().toString())){
            enviarToast("Informe o percentual a ser calculado");
            enviarResultado("Campo Percentual está vazio, informe o valor do percentual a ser aplicado");
            return false;
        }
        // campos foram preenchidos, guardamos os valores
        valorInput = inputPreco.getText().toString();
        percentualInput = inputPercentual.getText().toString();

        // verificar se ambos os valores são númericos
        try {
            valorInputNumero = Double.parseDouble(valorInput);
        } catch (NumberFormatException e) {
            enviarToast("O valor a ser calculado deve ter apenas números e um ponto decimal !!!");
            enviarResultado("Campo valor inválido, informe apenas números com apenas um ponto decimal !!!");
            return false;
        }

        try {
            percentualInputNumero = Double.parseDouble(percentualInput);
        } catch (NumberFormatException e) {
            enviarToast("O percentual a ser calculado deve ter apenas números e um ponto decimal !!!");
            enviarResultado("Campo Percentual inválido, informe apenas números com apenas um ponto decimal !!!");
            return false;
        }

        return true;
    }

}