package com.example.aula04;
/*
* Nome: Valter Sérgio ribeiro tertuliano
*
*
* */
import android.hardware.biometrics.BiometricManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView outputResultado;
    EditText inputNome, inputCargo, inputSalario;
    Switch inputAumento;
    SeekBar inputBarraAumento;
    Button btnCalcular;
    int valorSeekBar = 0;
    double salarioInput;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Iniciando elementos
        outputResultado = findViewById(R.id.outputResultado);
        inputNome = findViewById(R.id.inputNome);
        inputCargo = findViewById(R.id.inputCargo);
        inputSalario = findViewById(R.id.inputSalario);
        inputAumento = findViewById(R.id.inputAumento);
        inputBarraAumento = findViewById(R.id.inputBarraAumento);
        btnCalcular = findViewById(R.id.btnCadastrar);

        // configurando o seekbar para ficar inativo
        //isso é para fazer com que o aumento seja definido apenas se o switch for ativado ;)
        inputBarraAumento.setEnabled(false);
        inputBarraAumento.setMax(75); // define o limite maximo para a porcentagem

        // cria o evento do switch
        inputAumento.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(@NonNull CompoundButton buttonView, boolean isChecked) {
                // ativa o seekbar
                inputBarraAumento.setEnabled(true);
            }
        });

        // cria o evento do seekbar
        inputBarraAumento.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valorSeekBar = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                enviarResultado("Aumento em " + valorSeekBar + "%");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // registra o valor da porcentagem definido
                enviarResultado("Aumento em " + valorSeekBar + "%");
            }
        });

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarNotificacao("aqui -> " + valorSeekBar);
                // verifica se tem algum campo de entrada que está vazio
                if (!checarEntrada(inputNome.getText().toString())){
                    enviarResultado("Escreva o nome do ser humano cabaço !!!");
                    return;
                }

                if (!checarEntrada(inputCargo.getText().toString())){
                    enviarResultado("Escreva o cargo do ser humano cabaço !!!");
                    return;
                }

                if (!checarEntrada(inputSalario.getText().toString())){
                    enviarResultado("Informe o salario do ser humano cabaço");
                    return;
                }

                // verifica se o campo salario possui valores númericos
                try {
                    salarioInput = Double.parseDouble(inputSalario.getText().toString());

                } catch (NumberFormatException e) {
                    enviarResultado("O sálario informado deve ter apenas números, e apenas um ponto para valor decimal cabaço !!!");
                    return;
                }
                String mensagem = "Nome: " + inputNome.getText().toString() + "\n" +
                                    "Cargo: " + inputCargo.getText().toString() + "\n";

                // verifica se o aumento foi ativado
                if (!inputAumento.isChecked()){
                    enviarResultado(mensagem + "Sálario: " + salarioInput);
                } else {

                    // calcula
                    double novoSalario = salarioInput + (salarioInput * (valorSeekBar / 100.0));
                    enviarResultado(mensagem + "Sálario anterior: " + inputSalario.getText().toString() + "\n" + "Salario: " + novoSalario);
                }

                enviarNotificacao("Cabaço cadastrado com sucesso !!!!");
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private boolean checarEntrada(String entrada){
        // checa se a entrada é null, trim remove espaços em excesso e isEmpty checa se o comprimento (lenght) é 0
        // retorna true se a string não estiver vazia
        return entrada != null && !entrada.trim().isEmpty();
    }

    // Método para enviar notificaçao (Extremamente util)
    private void enviarNotificacao(String mensagem){
        Toast.makeText(MainActivity.this, mensagem, Toast.LENGTH_LONG).show();
    }

    private void enviarResultado(String resultado){
        outputResultado.setText(resultado);
    }

}