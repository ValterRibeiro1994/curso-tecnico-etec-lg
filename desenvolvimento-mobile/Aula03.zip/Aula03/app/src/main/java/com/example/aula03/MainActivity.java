package com.example.aula03;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    ImageView fotoAtual;
    Button btnAnterior, btnProximo;
    String nomeFotoAtual;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // inicia uma foto inicial
        fotoAtual =  findViewById(R.id.imgAleatoria);
        fotoAtual.setImageResource(R.drawable.fotoc);
        nomeFotoAtual = "index";
        fotoAtual.setImageResource(R.drawable.fotoc);

        // criando evento para botão anterior
        btnAnterior = findViewById(R.id.btnAnterior);
        btnAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nomeFotoAtual.equals("index")){
                    // a foto index é C, vamos recuar para B
                    nomeFotoAtual = "fotoB";
                    fotoAtual.setImageResource(R.drawable.fotob);
                } else if (nomeFotoAtual.equals("fotoB")){
                    // se a foto for B recuamos para A
                    nomeFotoAtual = "fotoA";
                    fotoAtual.setImageResource(R.drawable.fotoa);
                } else if (nomeFotoAtual.equals("fotoA")){
                    // se a foto for A voltamos para a foto index
                    nomeFotoAtual = "index";
                    fotoAtual.setImageResource(R.drawable.fotoc);
                } else {
                    // notifica algo está estranho aqui rsrsr
                    Toast.makeText(MainActivity.this, "Foto não indentificada", Toast.LENGTH_LONG).show();
                }
            }
        });

        // criando evento para o botão proximo
        btnProximo = findViewById(R.id.btnProximo);
        btnProximo.setOnClickListener(new View.OnClickListener() {
        @Override
            public void onClick(View v) {
            if (nomeFotoAtual.equals("index")){
                nomeFotoAtual = "fotoA";
                fotoAtual.setImageResource(R.drawable.fotoa);
            } else if (nomeFotoAtual.equals("fotoA")){
                nomeFotoAtual = "fotoB";
                fotoAtual.setImageResource(R.drawable.fotob);
            } else if (nomeFotoAtual.equals("fotoB")){
                nomeFotoAtual = "index";
                fotoAtual.setImageResource(R.drawable.fotoc);
            } else {
                Toast.makeText(MainActivity.this, "Algo estranho está rolando", Toast.LENGTH_LONG).show();
            }
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

}