package com.example.aula09;

public class Usuario {
    private String nome;
    private String cargo;
    private String cpf;
    private String endereco;

    // Construtor 1
    public Usuario(){}

    // Construtor 2
    public Usuario(String nome, String cargo, String cpf, String endereco){
        this.nome = nome;
        this.cargo = cargo;
        this.cpf = cpf;
        this.endereco = endereco;
    }

    // getter e setters

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    //Método toString()
    @Override
    public String toString()
    {
        return "Nome: " + nome + ", " +
                "cargo: " + cargo + ", " +
                "Cpf: " + cpf + ", " +
                "Endereco: " + endereco;
    }

}
