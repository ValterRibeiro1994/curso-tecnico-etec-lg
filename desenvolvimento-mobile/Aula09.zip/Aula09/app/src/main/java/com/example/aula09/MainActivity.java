package com.example.aula09;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // propriedades da classe
    EditText inputNome, inputCargo, inputCpf, inputEndereco;
    Button botaoCadastrar;
    ListView listaDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // inicia os elementos da tela
        inputNome = findViewById(R.id.inputNome);
        inputCargo = findViewById(R.id.inputCargo);
        inputCpf = findViewById(R.id.inputCpf);
        inputEndereco = findViewById(R.id.inputEndereco);
        botaoCadastrar = findViewById(R.id.botaoCadastro);
        listaDados = findViewById(R.id.listaDados);

        // cria um vetor de usuarios
        ArrayList<Usuario> vetorUsuarios = new ArrayList<Usuario>();

        // criar evento cadastro
        botaoCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = inputNome.getText().toString();
                String cargo = inputCargo.getText().toString();
                String cpf = inputCpf.getText().toString();
                String endereco = inputEndereco.getText().toString();

                // instancia a entidade Usuario
                Usuario usuario = new Usuario(nome, cargo, cpf, endereco);

                // adiciona o usuario no vetor
                vetorUsuarios.add(usuario);

                // cria um adaptador
                ArrayAdapter<Usuario> adaptadorLista = new ArrayAdapter<>(
                        MainActivity.this,
                        android.R.layout.simple_list_item_1,
                        vetorUsuarios
                );

                // insere o adaptador na listView
                listaDados.setAdapter(adaptadorLista);

                // limpa os campos de input
                inputNome.setText("");
                inputCargo.setText("");
                inputCpf.setText("");
                inputEndereco.setText("");
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}